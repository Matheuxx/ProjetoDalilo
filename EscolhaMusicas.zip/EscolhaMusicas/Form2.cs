﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EscolhaMusicas
{
    public partial class Form2 : Form
    {
        private int indice;
        
        
        private double cont, rock, sertanejo, latina, trap, rap, br, sad;

        private void BtnD_MouseLeave(object sender, EventArgs e)
        {
            btnD.FlatAppearance.BorderSize = 3;
            btnD.FlatAppearance.BorderColor = DefaultBackColor;
        }

        private void BtnD_MouseEnter(object sender, EventArgs e)
        {
            btnD.FlatAppearance.BorderSize = 3;
            btnD.FlatAppearance.BorderColor = Color.Red;
        }

        private void BtnL_MouseLeave(object sender, EventArgs e)
        {
            btnL.FlatAppearance.BorderSize = 0;
            btnL.FlatAppearance.BorderColor = DefaultBackColor;
        }

        private void BtnL_MouseEnter(object sender, EventArgs e)
        {
            btnL.FlatAppearance.BorderSize = 3;
            btnL.FlatAppearance.BorderColor = Color.Green;
        }

        private void BtnL_Click(object sender, EventArgs e)
        {
            if(indice == 0)
            {
            sertanejo++;
            }
            indice++;
            cont++;
            if(indice == 1)
            {
                label1.ImageIndex = indice;
                br++;
            }
            else if( indice == 2)
            {
                label1.ImageIndex = indice;
                trap++;
            }
            else if(indice == 3)
            {
                label1.ImageIndex = indice;
                rock++;
            }
            else if(indice == 4)
            {
                label1.ImageIndex = indice;
                rap++;
            }
            else if(indice == 5)
            {
                label1.ImageIndex = indice;
                sad++;
            }else if(indice == 6)
            {
                label1.ImageIndex = indice;
                br++;
            }else if(indice == 7)
            {
                label1.ImageIndex = indice;
                rock++;
            }
            else if(indice == 8)
            {
                label1.ImageIndex = indice;
                trap++;
            }else if(indice == 9)
            {
                label1.ImageIndex = indice;
                latina++;
            }

            if(cont == 9)
            {
                sertanejo = (sertanejo / cont) * 100;
                sertanejo = Math.Round(sertanejo, 2);
                br = (br / cont) * 100;
                br = Math.Round(br, 2);
                trap = (trap / cont) * 100;
                trap = Math.Round(trap, 2);
                rock = (rock / cont) * 100;
                rock = Math.Round(rock, 2);
                sad = (sad / cont) * 100;
                sad = Math.Round(sad, 2);
                latina = (latina / cont) * 100;
                latina = Math.Round(latina, 2);
                MessageBox.Show("Rock: " + rock + "%\nSertanejo: " + sertanejo + "%\nBrasileira: " + br + "%\nLatina: " + latina +
                    "%\nTrap: " + trap + "%\nSad" + "%" + sad, "Percentual de gêneros que você ouve");
                this.Close();
            }
        }

        public Form2()
        {
            InitializeComponent();
            indice = 0;
        }

        private void BtnD_Click(object sender, EventArgs e)
        {
            indice++;
            cont++;
            label1.ImageIndex = indice;
            if (indice >= 1 && indice < 2)
            {
                label1.ImageIndex = indice;
                sertanejo--;
                if(sertanejo < 0)
                {
                    sertanejo = 0;
                }
            }
            else if (indice >= 2 && indice < 3)
            {
                label1.ImageIndex = indice;
                br--;
                if (br < 0)
                {
                    br = 0;
                }
            }
            else if (indice >= 3 && indice < 4)
            {
                label1.ImageIndex = indice;
                trap--;
                if (trap < 0)
                {
                    trap = 0;
                }
            }
            else if (indice >= 4 && indice < 5)
            {
                label1.ImageIndex = indice;
                rock--;
                if (rock < 0)
                {
                    rock = 0;
                }
            }
            else if (indice >= 5 && indice < 6)
            {
                label1.ImageIndex = indice;
                rock--;
                if (rock < 0)
                {
                    rock = 0;
                }
            }
            else if (indice >= 6 && indice < 7)
            {
                label1.ImageIndex = indice;
                sad--;
                if (sad < 0)
                {
                    sad = 0;
                }
            }
            else if (indice >= 7 && indice < 8)
            {
                label1.ImageIndex = indice;
                br--;
                if (br < 0)
                {
                    br = 0;
                }
            }
            else if (indice >= 8 && indice < 9)
            {
                label1.ImageIndex = indice;
                rock--;
                if (rock < 0)
                {
                    rock = 0;
                }
            }
            else if (indice >= 9 && indice < 10)
            {
                label1.ImageIndex = indice;
                rock--;
                if (rock < 0)
                {
                    rock = 0;
                }
            }
            else
            {
                label1.ImageIndex = indice;
                latina--;
                if (latina < 0)
                {
                    latina = 0;
                }
            }
            if (cont == 9)
            {
                sertanejo = (sertanejo / cont) * 100;
                sertanejo = Math.Round(sertanejo, 2);
                br = (br / cont) * 100;
                br = Math.Round(br, 2);
                trap = (trap / cont) * 100;
                trap = Math.Round(trap, 2);
                rock = (rock / cont) * 100;
                rock = Math.Round(rock, 2);
                sad = (sad / cont) * 100;
                sad = Math.Round(sad, 2);
                latina = (latina / cont) * 100;
                latina = Math.Round(latina, 2);
                MessageBox.Show("Rock: " + rock + "%\nSertanejo: " + sertanejo + "%\nBrasileira: " + br + "%\nLatina: " + latina +
                    "%\nTrap: " + trap + "%\nSad" + "%" + sad, "Percentual de gêneros que você ouve");
                this.Close();
            }
        }
        }
    }
