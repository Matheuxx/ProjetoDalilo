﻿namespace EscolhaMusicas
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.btnD = new System.Windows.Forms.Button();
            this.lblMusicas = new System.Windows.Forms.Label();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.btnL = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnD
            // 
            this.btnD.BackgroundImage = global::EscolhaMusicas.Properties.Resources.D;
            this.btnD.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnD.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnD.Location = new System.Drawing.Point(394, 327);
            this.btnD.Name = "btnD";
            this.btnD.Size = new System.Drawing.Size(90, 75);
            this.btnD.TabIndex = 1;
            this.btnD.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.btnD.UseVisualStyleBackColor = true;
            this.btnD.Click += new System.EventHandler(this.BtnD_Click);
            this.btnD.MouseEnter += new System.EventHandler(this.BtnD_MouseEnter);
            this.btnD.MouseLeave += new System.EventHandler(this.BtnD_MouseLeave);
            // 
            // lblMusicas
            // 
            this.lblMusicas.AutoSize = true;
            this.lblMusicas.Location = new System.Drawing.Point(277, 114);
            this.lblMusicas.Name = "lblMusicas";
            this.lblMusicas.Size = new System.Drawing.Size(0, 13);
            this.lblMusicas.TabIndex = 2;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "Adeus Meu Amor - Bruno e Barreto.PNG");
            this.imageList1.Images.SetKeyName(1, "Ainda Gosto Dela - Skank.PNG");
            this.imageList1.Images.SetKeyName(2, "Bad Bad Bad - Young Thug.PNG");
            this.imageList1.Images.SetKeyName(3, "Californication - RHCP.PNG");
            this.imageList1.Images.SetKeyName(4, "Frio - Sant.PNG");
            this.imageList1.Images.SetKeyName(5, "Can\'t get over you - Joji.PNG");
            this.imageList1.Images.SetKeyName(6, "Chegou de Manso - Lagum.PNG");
            this.imageList1.Images.SetKeyName(7, "Dammit - blink 182.PNG");
            this.imageList1.Images.SetKeyName(8, "Want my M\'s - Kap G.PNG");
            this.imageList1.Images.SetKeyName(9, "Diavla - Chris Viz.PNG");
            // 
            // label1
            // 
            this.label1.ImageIndex = 0;
            this.label1.ImageList = this.imageList1;
            this.label1.Location = new System.Drawing.Point(228, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(256, 256);
            this.label1.TabIndex = 3;
            // 
            // btnL
            // 
            this.btnL.BackColor = System.Drawing.Color.Transparent;
            this.btnL.BackgroundImage = global::EscolhaMusicas.Properties.Resources.L;
            this.btnL.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnL.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnL.Location = new System.Drawing.Point(231, 327);
            this.btnL.Name = "btnL";
            this.btnL.Size = new System.Drawing.Size(90, 75);
            this.btnL.TabIndex = 0;
            this.btnL.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.btnL.UseVisualStyleBackColor = true;
            this.btnL.Click += new System.EventHandler(this.BtnL_Click);
            this.btnL.MouseEnter += new System.EventHandler(this.BtnL_MouseEnter);
            this.btnL.MouseLeave += new System.EventHandler(this.BtnL_MouseLeave);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DimGray;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblMusicas);
            this.Controls.Add(this.btnD);
            this.Controls.Add(this.btnL);
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnL;
        private System.Windows.Forms.Button btnD;
        private System.Windows.Forms.Label lblMusicas;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ImageList imageList1;
    }
}